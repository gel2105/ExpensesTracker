<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="card">
        <div class="card-header">
            <h1>Expenses Tracker</h1>
        </div>
        <div class="card-body">
            <form action="login-user.php" method="POST" autocomplete="">
                <h2 class="text-center">Login</h2>
                <p class="text-center">Login with your email and password.</p>
                <?php
                if(count($errors) > 0){
                    ?>
                    <div class="alert alert-danger text-center">
                        <?php
                        foreach($errors as $showerror){
                            echo $showerror;
                        }
                        ?>
                    </div>
                    <?php
                }
                ?>
                <div class="form-group mt-3">
                    <input class="form-control" type="email" name="email" placeholder="Email Address" required value="<?php echo $email ?>">
                </div>
                <div class="form-group mt-3">
                    <input class="form-control" type="password" name="password" placeholder="Password" required>
                </div>
                <div class="link forget-pass text-left mt-2"><a href="forgot-password.php">Forgot password?</a></div>
                <div class="form-group mt-3">
                    <input class="btn-login" type="submit" name="login" value="Login">
                </div>
                <div class="link login-link text-center mt-1">Don't have an account? <a href="signup-user.php">Signup now</a></div>
            </form>
        </div>
    </div>
</body>
</html>
